window.onload = function() {
	var items = document.getElementsByClassName('image');/*获取所有指定类名的元素*/

	var points = document.getElementsByClassName('point');/*获取所有指定类名的元素*/

	var gopreBtn = document.querySelector('.btn-left');   /*返回匹配指定选择器的第一个元素*/

	var goNextBtn = document.querySelector('.btn-right');  /*返回匹配指定选择器的第一个元素*/

	var index = 0;

	var time=0;

	auto();

	var clearActive = function() {            /*清理图片和中间的点的样式*/
		for (var i = 0;i<items.length;i++){
    	items[i].className = 'image';
        }
        for (var i = 0;i<points.length;i++){
    	points[i].className = 'point';
        }
	}

	var goIndex = function() {               /*给图片和中间的点加样式*/
    clearActive();
    items[index].className = 'image on';
    points[index].className = 'point on';
	}

	var goNext = function() {                 /*右按钮*/
		if(index <2){
			index++;
		}
		else{
			index = 0;
		}
		goIndex();
	}
	var goprebtn = function() {               /*左按钮*/
		if(index==0){
			index = 2;
		}else{
			index--;
		}
		goIndex();
	}
      goNextBtn.addEventListener('click',function() {        /*右按钮点击事件*/
          goNext();
         time=0;
      })
     
     gopreBtn.addEventListener('click',function() {   
           goprebtn();        								 /*左按钮点击事件*/
           time=0;
     })

	for (var i = 0;i < points.length ; i++) {                       /*中间按钮点击事件*/
		points[i].addEventListener('click',function() {
			console.log("abc")
			var pointIndex = this.getAttribute('data-index');/*获取data-index的数值*/
	             index = pointIndex;
	              goIndex();       
	              time=0;               
		})
	}
	 function auto(){                   /*定时器*/
		setInterval(function() {
			time++;
			if(time==40) {
			 goNext();
			 time=0;
			}
		},100);
	}
}
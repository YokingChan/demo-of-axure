//自定义sleep函数
function sleep(delay) {
    var start = (new Date()).getTime();
    while ((new Date()).getTime() - start < delay) {
      continue;
    }
}

//账户名和密码初始化，实现ajax get通讯
//func为
class Root { 
    constructor() {
        this.jsonData;
    }
    //新增用户/工作人员，需要传入输入用户名，密码和权限
    writeUser = function(username,pwd,authority,number,writeflag){
        if (writeflag)
            writeflag = "true";
        else
            writeflag = "false";
        var urlstring = 'http://39.108.105.2:80/api/'+'?'+
        'status=wirteDataUsers'+'&'+'username='+username+'&'+'pwd='+pwd+"&"+"authority="+authority+"&"+"number="+number+"&"+"writeflag="+writeflag;
        var _this = this;
        $.ajax({
                url:urlstring,
                type:"get",
                async:false,
                success:function(data){
                        _this.jsonData = data;
                        return 1;},
                error:function(data){return 0;}
            }); 
        sleep(30);
        return this.jsonData;
    }
    //将某个用户/工作人员删除，输入username，删除username对应的用户/工作人员数据
    deletUser = function(username){
        var urlstring = 'http://39.108.105.2:80/api/'+'?'+
        'status=deleteDataUsers'+'&'+'username='+username;
        var _this = this;
        $.ajax({
                url:urlstring,
                type:"get",
                async:false,
                success:function(data){
                        _this.jsonData = data;
                        return 1;},
                error:function(data){return 0;}
            }); 
        sleep(30);
        return this.jsonData;
    }
    //将username设置为下次自动登录用户，下次进入网页，将不需要登录，自动登录username对应用户
    setNextUser = function(username){
        var urlstring = 'http://39.108.105.2:80/api/'+'?'+
        'status=writeNextUser'+'&'+'username='+username;
        var _this = this;
        $.ajax({
                url:urlstring,
                type:"get",
                async:false,
                success:function(data){
                        _this.jsonData = data;
                        return 1;},
                error:function(data){return 0;}
            }); 
        sleep(30);
        return this.jsonData;
    }
        //将username设置为下次自动登录用户，下次进入网页，将不需要登录，自动登录username对应用户
    setActivityState = function(){
        var urlstring = 'http://39.108.105.2:80/api/'+'?'+
        'status=setActivityState'+'&'+'activityState='+"true";
        var _this = this;
        $.ajax({
                url:urlstring,
                type:"get",
                async:true,
                success:function(data){
                        _this.jsonData = data;
                        return 1;},
                error:function(data){return 0;}
            }); 
        sleep(30);
        console.log("发送心跳包");
        return this.jsonData;
    }
    //记录已经登录的用户，记录为用户名
    setLoginedUser = function(username){
        var urlstring = 'http://39.108.105.2:80/api/'+'?'+
        'status=writeLoginedUser'+'&'+'username='+username;
        var _this = this;
        $.ajax({
                url:urlstring,
                type:"get",
                async:false,
                success:function(data){
                        _this.jsonData = data;
                        return 1;},
                error:function(data){return 0;}
            }); 
        sleep(30);
        return this.jsonData;
    }
    //修改人员权限
    changeJsonAuthority = function(username,authority){
        var urlstring = 'http://39.108.105.2:80/api/'+'?'+
        'status=changeJsonAuthority'+'&'+'username='+username+'&'+'authority='+authority;
        var _this = this;
        $.ajax({
                url:urlstring,
                type:"get",
                async:false,
                success:function(data){
                        _this.jsonData = data;
                        return 1;},
                error:function(data){return 0;}
            }); 
        sleep(30);
        return this.jsonData;
    }
    //修改人员权限
    checkPwd = function(username,pwd){
        var urlstring = 'http://39.108.105.2:80/api/'+'?'+
        'status=checkpwd'+'&'+'username='+username+'&'+"pwd="+pwd;
        var _this = this;
        $.ajax({
                url:urlstring,
                type:"get",
                async:false,
                success:function(data){
                        _this.jsonData = data;
                        return 1;},
                error:function(data){return 0;}
            }); 
        sleep(30);
        return this.jsonData;
    }
    getNextLoginUser = function(){
        var urlstring = 'http://39.108.105.2:80/api/'+'?'+
        'status=getNextLoginUser';
        var _this = this;
        $.ajax({
            url:urlstring,
            type:"get",
            async:false,
            success:function(data){
                _this.jsonData = data;
                    return 1;},
            error:function(data){return 0;}
        });  
        sleep(30);
        return this.jsonData;
    }
    getJson = function(){
        var urlstring = 'http://39.108.105.2:80/api/'+'?'+
        'status=getJson';
        var _this = this;
        $.ajax({
            url:urlstring,
            type:"get",
            async:false,
            success:function(data){
                    _this.jsonData = data;
                    return 1;},
            error:function(data){return 0;}
        });  
        sleep(30);
        return this.jsonData;
    }
    //得到已经登录用户的用户名和用户性质，以数组形式返回，数组 第一个元素是用户名，第二个元素是用户性质
    getLoginedUsername = function(){
        var urlstring = 'http://39.108.105.2:80/api/'+'?'+
        'status=getLoginedUsername';
        var _this = this;
        $.ajax({
            url:urlstring,
            type:"get",
            async:false,
            success:function(data){
                    _this.jsonData = data;
                    return 1;},
            error:function(data){return 0;}
        });  
        sleep(30);
        return this.jsonData;
    }
}

var serverRoot = new Root();
// serverRoot.hello = function (){
//     console.log("helloworld");
// }



















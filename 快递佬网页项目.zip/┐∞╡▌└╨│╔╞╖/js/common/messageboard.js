
// var input01 = document.getElementById('input').getElementsByTagName('input');

	var input01 = document.getElementById('inputs');
	var textarea = document.getElementById('input1');
	function checkForm() {
		console.log(22);
		var content = textarea.value;
		if(content!=""){
			console.log(content)
			var div001 = document.createElement("div")
			div001.className="div02"
			div001.style.width="680px"
			div001.style.height="108px"
			div001.style.border="1px solid black"
			div001.style.background="#fff"
			div001.style.margin="12px auto"
			div001.style.top="0px"
			var p01 = document.createElement("p")
			p01.innerHTML="   "+content
			div001.appendChild(p01)
			var div02 = document.getElementsByClassName("div02")[0]
			var div002 = document.getElementById('message1');
			document.getElementById('message').insertBefore(div001,div002);
			document.getElementById('message').insertBefore(div002,div002);
			}
			return false;
		}
    
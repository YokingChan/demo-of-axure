var top_fr_b = document.getElementsByClassName("top_fr_a");
var oChooseDay = document.getElementsByClassName("chooseDay")[0];
var oPtion1 = oChooseDay.getElementsByTagName("option")[0];
var oPtion2 = oChooseDay.getElementsByTagName("option")[1];
var addOne = document.getElementById("addone");
var minusOne = document.getElementById("minusone");
var nu = document.getElementById("n");
var oWpType = document.getElementsByClassName("wpType")[0];
var oRemarksBtn = oWpType.getElementsByTagName("a");
var oRegister = document.getElementById("register");
var tmpDate=new Date();
var index1 = 0;
var obj = serverRoot.getLoginedUsername();
/*-----------------------------------------------------------------------------------------------------------*/
/*获取日期  开始*/
var dateConversion = new Map([[0, '星期日'], [1, '星期一'], [2, '星期二'],[3, '星期三'],[4, '星期四'],[5,'星期五'],[6,'星期六']]);
var setHtmlTakeTime1 = function (day) {
    document.getElementById("data1").value=tmpDate.getFullYear()+"-"+(tmpDate.getMonth()+1)+"-"+(tmpDate.getDate())+" "+day+" "+"今天";
    oPtion1.innerText=document.getElementById("data1").value;  
}
setHtmlTakeTime1(dateConversion.get(tmpDate.getDay()));    /*当天日期*/
var setHtmlTakeTime2 = function (day) {
    var cond1 = tmpDate.getFullYear() % 4 == 0;  //条件1：年份必须要能被4整除
    var cond2 = tmpDate.getFullYear() % 100 != 0;  //条件2：年份不能是整百数
    var cond3 = tmpDate.getFullYear() % 400 ==0;    //条件3：年份是400的倍数
    var cond = cond1 && cond2 || cond3;
    var date = tmpDate.getDate();
    var month = (tmpDate.getMonth()+1);
    if(day>=6){      
        day=0;
        day = dateConversion.get(day);
    }else{
        day = dateConversion.get(++day);
    }
  var change;
  var change_m = (function (){
    
    if (month == 1||month == 3||month == 5||month == 7||month == 8||month == 10||month == 12 ) {
        change = 0;
         }
    else if(month == 4||month == 6||month == 9||month == 11) {
        change = 1;
    }
    else {
    change = 2;
    }
   return change;
    })();
    switch(change_m) { 
    case 0:
    if(tmpDate.getDate()>30){
      document.getElementById("data2").value=tmpDate.getFullYear()+"-"+(tmpDate.getMonth()+2)+"-"+(date = 1)+" "+day+" "+"明天";
    }
    else {
    document.getElementById("data2").value=tmpDate.getFullYear()+"-"+(tmpDate.getMonth()+1)+"-"+(date+1)+" "+day+" "+"明天";
     }
    oPtion2.innerText=document.getElementById("data2").value;
    break;
    case 1:
     if(tmpDate.getDate()>29){
      document.getElementById("data2").value=tmpDate.getFullYear()+"-"+(tmpDate.getMonth()+2)+"-"+(date = 1)+" "+day+" "+"明天";
    }
    else {
    document.getElementById("data2").value=tmpDate.getFullYear()+"-"+(tmpDate.getMonth()+1)+"-"+(date+1)+" "+day+" "+"明天";
     }
      oPtion2.innerText=document.getElementById("data2").value;
     break;    
    case 2:
    if(cond&&(tmpDate.getDate()>28)) {
        document.getElementById("data2").value=tmpDate.getFullYear()+"-"+(tmpDate.getMonth()+2)+"-"+(date = 1)+" "+day+" "+"明天";
      }
    else if(tmpDate.getDate()>27) {
        document.getElementById("data2").value=tmpDate.getFullYear()+"-"+(tmpDate.getMonth()+2)+"-"+(date = 1)+" "+day+" "+"明天";
    }
    else{
         document.getElementById("data2").value=tmpDate.getFullYear()+"-"+(tmpDate.getMonth()+1)+"-"+(date + 1)+" "+day+" "+"明天";
    }
     oPtion2.innerText=document.getElementById("data2").value;
     break;
    }
}
setHtmlTakeTime2(tmpDate.getDay());                      /*后一天的日期*/
/*获取日期    结束*/
/*--------------------------------------------------------------------------------------------------------------------------*/

 /* 加减法按钮 */ 
       addOne.addEventListener('click',function() {        /*加法按钮点击事件*/
        nu.value++;
    })
    minusOne.addEventListener('click',function() {        /*减法按钮点击事件*/
        if(nu.value<1) {
            alert("公斤数不能小于0");
        }
        else{
            nu.value--;
            }
    })
/*--------------------------------------------------------------------------------------------------------------------------------*/
for(var i=0;i<oRemarksBtn.length;i++) {                     /*物品类型选择框*/
    oRemarksBtn[i].index=i;
    oRemarksBtn[i].onclick = function() {
        for(var j=0;j<oRemarksBtn.length;j++) {
            oRemarksBtn[j].className ="remarksBtn hand";
        }
             this.className = "remarksBtn hand on";
    }
}
oRegister.innerText = obj.username;

function confirm() {
    alert("抱歉，您的信息没填完整，下单失败！");
 
}

var t1 = window.setInterval("serverRoot.setActivityState()", 913);


var addOne = document.getElementById("addone");
var minusOne = document.getElementById("minusone");
var nu = document.getElementById("n");
var oWpType = document.getElementsByClassName("wpType")[0];
var oRemarksBtn = oWpType.getElementsByTagName("a");
var oSwitchover = document.getElementById("switchover");
var oRegister = document.getElementById("register");
var oLogin = document.getElementById("login"); 
var obj =  serverRoot.getLoginedUsername();

for(var i=0;i<oRemarksBtn.length;i++) {                 /* 选择物品类型 */
    oRemarksBtn[i].index=i;
    oRemarksBtn[i].onclick = function() {
        for(var j=0;j<oRemarksBtn.length;j++) {
            oRemarksBtn[j].className ="remarksBtn hand";
        }
             this.className = "remarksBtn hand on";
    }
}

       /* 加减法按钮 */ 
addOne.addEventListener('click',function() {        /*加法按钮点击事件*/
    nu.value++;
})
minusOne.addEventListener('click',function() {        /*减法按钮点击事件*/
    if(nu.value<1) {
        alert("公斤数不能小于0");
    }
    else{
        nu.value--;
        }
})
function confirm() {
    alert("抱歉，您的信息没填完整，下单失败！");
    
}
var t1 = window.setInterval("serverRoot.setActivityState()", 913);
oRegister.innerText = obj.username;           /* 把登录的用户呈现出来 */    
   





























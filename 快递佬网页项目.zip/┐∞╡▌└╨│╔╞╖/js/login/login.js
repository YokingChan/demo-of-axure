
var log = console.log;
/* 心跳包 */
var t1 = window.setInterval("serverRoot.setActivityState()", 913);
/* 登录后显示用户名 */
(function () {
    var obj1 = serverRoot.getLoginedUsername();
    var obj2 = serverRoot.getNextLoginUser();
    var loginRegister = document.getElementById("login-register");
    if(obj1.has) {      
        loginRegister.innerText = obj1.username;
    } else if(obj2.has) {
        loginRegister.innerText = obj2.username;
    } else {
        loginRegister.innerText = "登录/注册";
    }
})();
document.getElementById("btn_showlogin").onclick = shogMinLogin;
document.getElementById("close_minilogin").onclick = closeLogin;
// document.getElementById("firstLine").onmousedown = moveLogin;
// (function aa() {
//     var obj = serverRoot.getNextLoginUser();
//     var loginRegister = document.getElementById("login-register");
//     if(obj.has) {      
//         loginRegister.innerText = obj.username;       
//     } else {
//         loginRegister.innerText = "登录/注册";
//     }
// })();
    /* 显示登录窗口 */
function shogMinLogin(){
    if(!serverRoot.getLoginedUsername().has){
        var mini_login = document.getElementsByClassName("mini_login")[0];
        var cover = document.getElementsByClassName("cover")[0];
        mini_login.style.display = "block";
        cover.style.display = "block";
        mini_login.style.left = (document.body.scrollWidth - mini_login.scrollWidth) / 2 + "px";
        mini_login.style.top = (document.body.scrollHeight + mini_login.scrollHeight) / 9 + "px";
    }
}
    /* 关闭登录窗口 */
function closeLogin(){
    var mini_login = document.getElementsByClassName("mini_login")[0];
    var cover = document.getElementsByClassName("cover")[0];
    mini_login.style.display = "none";
    cover.style.display = "none";
}
    // money哥杰作
var oitem = document.getElementsByClassName("item")[0];
var oa = oitem.getElementsByTagName("span");
var ofather = document.getElementsByClassName("father")[0];
var ob = ofather.getElementsByTagName("article");
for(var i = 0; i < oa.length; i++) {            /*我的信息窗口页面切换*/
    oa[i].index = i;
    oa[i].onclick = function() {
        for(var j = 0; j<oa.length; j++) {
            oa[j].className = "hide login_title";
            ob[j].className = "active";
        }
        this.className = "login_title on";
        ob[this.index].className = "show";
    }
}
    /* 移动登录窗口 */
    // function moveLogin(event){
    //     var moveable = true;

    //     //获取事件源
    //     event = event ? event : window.event;
    //     var clientX = event.clientX;
    //     var clientY = event.clientY;
        
    //     var mini_login = document.getElementById("mini_login");
    //     console.log(mini_login);
    //     var top = parseInt(mini_login.style.top);
    //     var left = parseInt(mini_login.style.left);//鼠标拖动
    //     document.onmousemove = function(event){
    //         if(moveable){
    //             event = event ? event : window.event;
    //             var y = top + event.clientY - clientY;
    //             var x = left + event.clientX - clientX;
    //             if(x>0 && y>0){
    //                 mini_login.style.top = y + "px";
    //                 mini_login.style.left = x + "px";
    //             }
    //         }
    //     }
    //     //鼠标弹起
    //     document.onmouseup = function(){
    //         moveable = false;
    //     }
    // }
// };

//下次登录按钮点击标志，默认情况下为没有点击
var nextLoginFlag = false;
// (function(){
//     // 获取自动登录账号对象
//     obj = serverRoot.getNextLoginUser();
//     // 判断是否有自动登录账号，如果有，进行登录
//     if(obj.has){
//         // 将自动登录的账号的账号名更新到已经登录账号里面
//         serverRoot.setLoginedUser(obj.username);  
//         //跳转到登录后的页面
//         window.location.href = '../html/login-jump.html';
//     }
// }());

// submit 登录账户和密码判定
function canFormCheck() {
    var username = document.getElementById('username');
    var pwd = document.getElementById('password');
    var ofont2 = document.getElementById("font2");
    var checkResult = serverRoot.checkPwd(username.value,pwd.value);
    if(checkResult.result){
        //登录前记录录登录账号
        console.log(checkResult.username)
        serverRoot.setLoginedUser(checkResult.username);
        //判定用户有没有点击下次登录，下次登录按钮被激活的时候，将json数据库的LoginedUser设置username
        if(nextLoginFlag){
            serverRoot.setNextUser(checkResult.username);
        }
        else 
            serverRoot.setNextUser(null);         
            window.location.href = '../html/index.html';        
    }
    else{
        ofont2.innerText = "输入密码有误";     
    }  
    return false;
}

// 下次登录方框勾选案例触发按键
function setPositionBox() {
    var squareBox = document.getElementById('box');
    // 默认情况下为没有点击
    if(nextLoginFlag == false){
        //显示打勾，并且设置自动登录标志 
        squareBox.style.backgroundPosition = '-61px -17px';
        nextLoginFlag = true;
    }
    else{
        //取消打勾，并且取消自动登录标志 
        squareBox.style.backgroundPosition = '-38px -16px';
        nextLoginFlag = false;
    }
}
/* 判断输入的数字是否符合规格 */
function register() {  
    var ofont = document.getElementById("font");
    var number = document.getElementById("phone-number").value; 
    var reg=/^\d+$/;
    var onumber = reg.test(number);
    if(onumber&&number.length==11){
        ofont.innerText="";
        return true;
    }else if(number=="") {
        ofont.innerText= "请输入手机号码";
        return false;
    } else{
        ofont.innerText = "输入的手机号码有误" ;
        return false;
        }
    }
/* 判断两次输入的密码是否一致 */
var ojudge = document.getElementById("judge");
function judge() {
        var opasswordf = document.getElementById("password-f").value;
        var opasswords = document.getElementById("password-s").value;
        if(opasswordf==opasswords) {
            ojudge.innerText = "";
            return true;
        }
        else{
            ojudge.innerText = "两次密码不一致，请重新输入" ;
            return false;
        }
    }
/* 显示和隐藏密码 */
var ele_pass_box = document.getElementsByClassName("pass-register")[0];        
var ele_pass = ele_pass_box.getElementsByTagName("input")[0];
var ele_eye = ele_pass_box.getElementsByTagName("img")[0];
ele_eye.onclick = function () {
    var state = ele_eye.getAttribute("state");
    if(state === "off") {
        ele_pass.setAttribute("type", "text");
        ele_eye.setAttribute("state", "on");
        ele_eye.src = "../images/login/eyes1.png";
    } else {
        ele_pass.setAttribute("type", "password");
        ele_eye.setAttribute("state", "off");
        ele_eye.src = "../images/login/eyes2.png";
    }
}
/* 检查用户是否填写信息--用户名部分 */
 function check1() {
    var ocheck3 = document.getElementById("check3");
    var ousername = document.getElementById("user-name").value;
     if(ousername=="") {
        ocheck3.innerText = "请填写用户名";
        return false;
     } else {
        ocheck3.innerText = "";
        return true;
     }
 }
 /* 检查用户是否填写信息--密码部分 */
 var ocheck2 = document.getElementById("check2");
 function check2() {
    var opassword = document.getElementById("password-f").value;
     if(opassword=="") {
        ocheck2.innerText = "请输入密码";
        return false;
     } else {
        ocheck2.innerText = "";
        return true;
     }
 }
/* 用户名判断 */
function get1() {
    var oname = document.getElementsByClassName("user-names")[0].value;
    var judgeUser = serverRoot.writeUser(oname,"ff",false,"000000000",false);
    var userName = document.getElementById("check1");
    if(judgeUser.result==1) {     
        userName.innerText = "该用户已存在";
    } else if(judgeUser.result==0) {
        userName.innerText = "";
    }
}
/* 手机号码判断 */
function get2() {
    var number = document.getElementById("phone-number").value;
    var judgeUser = serverRoot.writeUser("aa","ff",false,number,false);
    var ofont1 = document.getElementById("font1");
    if(judgeUser.result==2) {
        ofont1.innerText = "该手机号已存在";
    } else if(judgeUser.result==0) {
        ofont1.innerText = "";
    }
}
/* 注册成功跳转 */
function canRegister() {
    var ousername = document.getElementById("user-name").value;
    var opassword = document.getElementById("password-f").value;
    var number = document.getElementById("phone-number").value;
    var opasswords = document.getElementById("password-s").value;
    var result = serverRoot.writeUser(ousername,opassword,false,number,false).result;
    var reg=/^\d+$/;
    var onumber = reg.test(number);
    if(result == "0"&&ousername.length<11&&opasswords == opassword && number.length == 11&&onumber&&ousername.length>0&&opassword!=""&&opasswords!="") {
        alert("恭喜您注册成功");
        serverRoot.writeUser(ousername,opassword,false,number,true);
        serverRoot.setLoginedUser(ousername);
        window.location.href = '../html/index.html';  
    }  else {
        alert("抱歉，注册失败");
        return false;
    }
}
/* 正则表达式判断注册的用户名 */
function judgeName() {
    var userName = document.getElementById("user-name").value;
    var ocheck4 = document.getElementById("check4");
    if(userName.length>10) {
        ocheck4.innerText = "输入的字符不能超过11个";
    } else {
        ocheck4.innerText = "";
    }
}

/* 点击我们的服务时候判断是否登录--开始 */
function skip1() {
    var obj = serverRoot.getLoginedUsername();
    if(obj.has) {
        window.location.href = 'replace.html'; 
    } else {
        alert("抱歉，请先登录");     
    }
    return false;
}
function skip2() {
    var obj = serverRoot.getLoginedUsername();
    if(obj.has) {
        window.location.href = 'part-time-job.html'; 
    } else {
        alert("抱歉，请先登录");     
    }
    return false;
}
function skip3() {
    var obj = serverRoot.getLoginedUsername();
    if(obj.has) {
        window.location.href = 'send.html'; 
    } else {
        alert("抱歉，请先登录");     
    }
    return false;
}
/* 点击我们的服务时候判断是否登录--结束 */
/* 注销账号返回主页 */
function logout() {  
    serverRoot.setLoginedUser(null);
    serverRoot.setNextUser("null");
    window.location.href = 'index.html';
}
/*判断是否注销账号*/
(function judge2() {
    var obj1 = serverRoot.getNextLoginUser();
    var obj2 = serverRoot.getLoginedUsername();
    var loginLogout = document.getElementById("login-logout");
    if(obj1.has||obj2.has) {
        loginLogout.innerText = "注销账号";
    } else {
        loginLogout ="";
    }
})();

console.log(serverRoot.getJson());

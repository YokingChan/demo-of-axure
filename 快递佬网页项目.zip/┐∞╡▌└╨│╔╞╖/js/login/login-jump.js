

(function(){
    console.log("用户："+serverRoot.getLoginedUsername().username+" 已经登录成功！");
}());

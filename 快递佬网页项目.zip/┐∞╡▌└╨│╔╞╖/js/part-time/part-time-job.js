   
    var  top_fr_b = document.getElementsByClassName("top_fr_a");

    var  oBanner2 = document.getElementById("banner2");

    var  oUl = oBanner2.getElementsByTagName("ul")[0];

    var oLi = oUl.getElementsByTagName("li");

    var oDiv = oBanner2.getElementsByTagName("div");
     
    var oContent_a = document.getElementsByClassName("content_a")[0];

    var oUl_a = oContent_a.getElementsByTagName("ul")[0];

    var oLi_a = oUl_a.getElementsByTagName("li");
   
    var oDt =  oContent_a.getElementsByTagName("dt");
     
    var oContent2 = document.getElementsByClassName("content2")[0];

    var oUl_r = oContent2.getElementsByTagName("ul")[0];

    var oLi_r = oUl_r.getElementsByTagName("li");

    var oChooseDay = document.getElementsByClassName("chooseDay")[0];

    var oPtion1 = oChooseDay.getElementsByTagName("option")[0];

    var oPtion2 = oChooseDay.getElementsByTagName("option")[1];

    var addOne = document.getElementById("addone");

    var minusOne = document.getElementById("minusone");
    
    var nu = document.getElementById("n");

    var tmpDate=new Date();
     
    var oRegister = document.getElementById("register");

    var index1 = 0;
     
    var obj = serverRoot.getLoginedUsername();

    
  /*加载第一个页面url   开始*/      
    function isMatch(str1,str2) 
   {   
        var index = str1.indexOf(str2); 
        if(index==-1) return false; 
        return true; 
   }
        if (isMatch(window.location.hostname,'www.123.com') == false){
        window.location.href="./part-time-job.html#banner1";}
/*加载第一个页面url   结束*/  
/*-----------------------------------------------------------------------------------------------------------------------*/

/* ------------------------------------------------------------------------------------- */
    var clearactive1 = function() {                
     for(var i=0;i<top_fr_b.length;i++) {
     	top_fr_b[i].className = "top_fr_a fl"
     }	
    } 
    var addonclick1 = function() {                 /*增加样式*/
    	clearactive1();
    	top_fr_b[index1].className = "top_fr_a  fl active"
    } 
    for(var i=0;i<top_fr_b.length;i++) {             
    	top_fr_b[i].onclick = function() {
              var pointIndex = this.getAttribute('data-index');
              index1 = pointIndex;
              addonclick1();
    	}
    }
 /*---------------------------------------------------------------------------------------------------------------*/   
    for(var i=0;i<oLi.length;i++) {            /*我的信息窗口页面切换*/
        oLi[i].index = i;
        oLi[i].onclick = function() {
            for(var j=0;j<oLi.length;j++) {
                oLi[j].className = "off";
                oDiv[j].className = "hide";
            }
            this.className = "on";
            oDiv[this.index].className = "show";
        }
    }
/*------------------------------------------------------------------------------------------------------------------*/
for(var i=0 ; i<oLi_a.length ; i++) {     //今日订单，待接单，已接单。。。。切换按钮
    oLi_a[i].index = i;
    oLi_a[i].onclick = function() {
        for(var j=0 ; j<oLi_a.length ; j++) {
            oLi_a[j].className = "receptacle_a off1";     
            oDt[j].className = "text_N hide";
        }
        this.className = "receptacle_a on1";
        oDt[this.index].className = "show_a text_N";
    }
  }

/* ------------------------------------------------------------------------------------------------------ */
for(var i=0 ; i<oLi_r.length;i++) {                     /* 充值记录，消费明细按钮 */
        oLi_r[i].index= i;
        oLi_r[i].onclick = function() {
          for(var j=0;j<oLi_r.length;j++) {
            oLi_r[j].className = "off2";
          }
          this.className="on2";
        }
}
/*-----------------------------------------------------------------------------------------------------------*/
/*获取日期  开始*/
var dateConversion = new Map([[0, '星期日'], [1, '星期一'], [2, '星期二'],[3, '星期三'],[4, '星期四'],[5,'星期五'],[6,'星期六']]);
var setHtmlTakeTime1 = function (day) {
    document.getElementById("data1").value=tmpDate.getFullYear()+"-"+(tmpDate.getMonth()+1)+"-"+(tmpDate.getDate())+" "+day+" "+"今天";
    oPtion1.innerText=document.getElementById("data1").value;  
}
setHtmlTakeTime1(dateConversion.get(tmpDate.getDay()));    /*当天日期*/

var setHtmlTakeTime2 = function (day) {
    var cond1 = tmpDate.getFullYear() % 4 == 0;  //条件1：年份必须要能被4整除
    var cond2 = tmpDate.getFullYear() % 100 != 0;  //条件2：年份不能是整百数
    var cond3 = tmpDate.getFullYear() % 400 ==0;    //条件3：年份是400的倍数
    var cond = cond1 && cond2 || cond3;
    var date = tmpDate.getDate();
    var month = (tmpDate.getMonth()+1);
    if(day>=6){      
        day=0;
        day = dateConversion.get(day);
    }else{
        day = dateConversion.get(++day);
    }
  var change;
  var change_m = (function (){
    
    if (month == 1||month == 3||month == 5||month == 7||month == 8||month == 10||month == 12 ) {
        change = 0;
         }
    else if(month == 4||month == 6||month == 9||month == 11) {
        change = 1;
    }
    else {
    change = 2;
    }
   return change;
    })();
    switch(change_m) { 
    case 0:
    if(tmpDate.getDate()>30){
      document.getElementById("data2").value=tmpDate.getFullYear()+"-"+(tmpDate.getMonth()+2)+"-"+(date = 1)+" "+day+" "+"明天";
    }
    else {
    document.getElementById("data2").value=tmpDate.getFullYear()+"-"+(tmpDate.getMonth()+1)+"-"+(date+1)+" "+day+" "+"明天";
     }
    oPtion2.innerText=document.getElementById("data2").value;
    break;

    case 1:
     if(tmpDate.getDate()>29){
      document.getElementById("data2").value=tmpDate.getFullYear()+"-"+(tmpDate.getMonth()+2)+"-"+(date = 1)+" "+day+" "+"明天";
    }
    else {
    document.getElementById("data2").value=tmpDate.getFullYear()+"-"+(tmpDate.getMonth()+1)+"-"+(date+1)+" "+day+" "+"明天";
     }
      oPtion2.innerText=document.getElementById("data2").value;
     break;
    
    case 2:
    if(cond&&(tmpDate.getDate()>28)) {
        document.getElementById("data2").value=tmpDate.getFullYear()+"-"+(tmpDate.getMonth()+2)+"-"+(date = 1)+" "+day+" "+"明天";
      }
    else if(tmpDate.getDate()>27) {
        document.getElementById("data2").value=tmpDate.getFullYear()+"-"+(tmpDate.getMonth()+2)+"-"+(date = 1)+" "+day+" "+"明天";
    }
    else{
         document.getElementById("data2").value=tmpDate.getFullYear()+"-"+(tmpDate.getMonth()+1)+"-"+(date + 1)+" "+day+" "+"明天";
    }
     oPtion2.innerText=document.getElementById("data2").value;
     break;
    }
}
setHtmlTakeTime2(tmpDate.getDay());                      /*后一天的日期*/
/*获取日期    结束*/
/*--------------------------------------------------------------------------------------------------------------------------*/

/*--------------------------------------------------------------------------------------------------------------------------------*/ 
var table = document.getElementById("alternatecolor");       /* 变换快递表格的颜色 */
var rows = table.getElementsByTagName("tr"); 
(function altRows(){
		for(i = 0; i < rows.length; i++){          
			if(i % 2 == 0){
				rows[i].className = "evenrowcolor";
			}else{
				rows[i].className = "oddrowcolor";
			}      
		}
	})();
var t1 = window.setInterval("serverRoot.setActivityState()", 913);
function confirm() {
  alert("接单成功！");
  window.location.href = '../html/index.html';
}
oRegister.innerText = obj.username;

